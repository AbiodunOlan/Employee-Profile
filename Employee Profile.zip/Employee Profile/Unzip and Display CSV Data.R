# Load necessary libraries
library(utils)

# Function to unzip and display data
unzip_and_display_data <- function(zip_file_path, extract_to_dir) {
  # Ensure the extraction directory exists
  if (!dir.exists(extract_to_dir)) {
    dir.create(extract_to_dir, recursive = TRUE)
  }
  
  # Unzip the file
  unzip(zip_file_path, exdir = extract_to_dir)
  
  # List the files in the extracted directory
  extracted_files <- list.files(extract_to_dir, full.names = TRUE)
  
  # Read and display the CSV file(s)
  for (file in extracted_files) {
    if (grepl("\\.csv$", file)) {
      df <- read.csv(file)
      print(paste("Contents of", file, ":"))
      print(df)
    }
  }
}

# Example usage
zip_file_path <- "C:/dataset/Employee Profile.zip"

extract_to_dir <- "Employee Profile/unzipped"

unzip_and_display_data(zip_file_path, extract_to_dir)
